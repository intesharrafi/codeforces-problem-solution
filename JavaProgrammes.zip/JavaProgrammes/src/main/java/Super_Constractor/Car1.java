
package Super_Constractor;

public class Car1 extends Vehicle1 {
    int speed = 100;
    
    public Car1()
    {
        super("Red");
        System.out.println("Car is Created\n");
    }
    
    public void display()
    {
        super.display();
        System.out.println("Vehicle Speed is: "+super.speed);
        System.out.println("Car Speed is: "+speed);
    }    
    
    public static void main(String[] args) {        
        
        Car1 c1 = new Car1();       
        c1.display();      
      }
    
}

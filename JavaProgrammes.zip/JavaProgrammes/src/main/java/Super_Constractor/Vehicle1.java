
package Super_Constractor;

public class Vehicle1 {
        int speed = 50;
    
    public Vehicle1(String color) {
        System.out.println("Vehicle is created with  color:" + color);
    }        

    public void display() {
        System.out.println("The vehicle Speed is: " + speed);
    }

    
}

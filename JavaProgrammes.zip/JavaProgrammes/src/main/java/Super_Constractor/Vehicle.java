
package Super_Constractor;

public class Vehicle {
    int Speed=50;
    public Vehicle(int Speed)
    {
        System.out.println("Vehicle is created");
        this.Speed=Speed;
    }
    
    
}

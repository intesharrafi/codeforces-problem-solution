
package Super_Constractor;

public class Test {
    public static void main(String[] args) {
        Car C1 = new Car();
        C1.display();
    }
    
}

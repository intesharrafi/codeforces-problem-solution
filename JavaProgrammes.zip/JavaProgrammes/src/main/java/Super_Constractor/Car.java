
package Super_Constractor;

public class Car extends Vehicle{
    
    public Car() {
        super(100);
        System.out.println("Car is Created");
    }
   public void display()
    {
        System.out.println(+super.Speed);
        System.out.println(+super.Speed);
    }
    
}

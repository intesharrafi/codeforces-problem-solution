package Abstraction;

public class Bird extends Animal{
    @Override
    public void eat()
    {
        System.out.println("Bird eats inseact");
    }
    @Override
    public void move()
    {
        System.out.println("Bird moves slowly");
    }
    public void fly()
    {
        System.out.println("Birds can fly");
    }
}

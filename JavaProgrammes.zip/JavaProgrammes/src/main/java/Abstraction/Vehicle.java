package Abstraction;

  public abstract class Vehicle {
    public abstract void move();
}


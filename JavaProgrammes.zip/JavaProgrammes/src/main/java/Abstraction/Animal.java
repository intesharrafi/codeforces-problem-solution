package Abstraction;

public abstract class Animal {
    public abstract void eat(); 
    public abstract void move();
    public void life()
    {
        System.out.println("life is Beautifull");
    }
}

package Abstraction;

public class Main_Animal {
    public static void main(String[] args) {
        Human H1 = new Human();
        Lion L1 = new Lion();
        Bird B1 = new Bird();
        H1.eat();
        H1.move();
        H1.talk();
        L1.eat();
        L1.move();
        L1.hunt();
        B1.eat();
        B1.move();
        B1.fly();
        H1.life();
    }
 
}

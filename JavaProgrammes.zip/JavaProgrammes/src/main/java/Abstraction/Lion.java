package Abstraction;

public class Lion extends Animal{
    @Override
    public void eat()
    {
        System.out.println("Lion eats meat");  
    }
    @Override
    public void move()
    {
        System.out.println("Lion moves fast");
    }
    public void hunt()
    {
        System.out.println("Lion can hunt");
    }
    
}

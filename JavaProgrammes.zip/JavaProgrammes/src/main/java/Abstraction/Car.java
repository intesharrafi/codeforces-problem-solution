package Abstraction;

public class Car extends Vehicle {
     @Override
     public void move()
    {
        System.out.println("Car moves Fast");  
    }
    public static void main(String[] args) {
        Car c1 = new Car();
        c1.move();
    }
}


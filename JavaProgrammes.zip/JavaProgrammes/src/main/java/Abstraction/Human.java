package Abstraction;

public class Human extends Animal{
    @Override
    public void eat()
    {
        System.out.println("Human eats everything");
    }
    @Override
    public void move()
    {
        System.out.println("Human moves fast"); 
    }
    public void talk()
    {
        System.out.println("Human Can talks");
    }
}

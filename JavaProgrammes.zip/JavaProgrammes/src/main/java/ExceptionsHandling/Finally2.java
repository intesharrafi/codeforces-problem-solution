
package ExceptionsHandling;

public class Finally2 {
    public static void main(String[] args) {
        int x=25;
        try
        {
            int num = x/0;
            System.out.println(num);
        }
        catch(ArithmeticException e)
        {
            System.out.println("Exception");
        }
        finally
        {
            System.out.println("Finally Block is alawas executed");
        }
        System.out.println("Rest of the code");
    }
}

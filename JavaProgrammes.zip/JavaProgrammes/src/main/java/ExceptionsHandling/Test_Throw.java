package ExceptionsHandling;

import static ExceptionsHandling.Throw.validDate;

public class Test_Throw {
    public static void main(String[] args) {
        validDate(13);
        System.out.println("Rest of the code");
    }
}

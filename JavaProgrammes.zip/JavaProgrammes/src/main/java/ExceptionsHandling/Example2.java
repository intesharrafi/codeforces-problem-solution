package ExceptionsHandling;

public class Example2 {
    public static void main(String[] args) {
        int a[] = new int [2];
        try
        {
            System.out.println(+a[3]);
        }
        catch(ArithmeticException e)
        {
            System.out.println("Arithmetic Exception");
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Array Index Out Of Bounds Exception");
        }
        catch(NullPointerException e)
        {
            System.out.println("NullPointer Exception");
        }
        
}
}
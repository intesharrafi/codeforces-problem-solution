package ExceptionsHandling;

public class Finally {
    public static void main(String[] args) {
        int x=25;
        try
        {
            int num = x/5;
            System.out.println(num);
        }
        catch(NullPointerException e)
        {
            System.out.println("Exception");
        }
        finally
        {
            System.out.println("Rest of the code");
        }
    }
}

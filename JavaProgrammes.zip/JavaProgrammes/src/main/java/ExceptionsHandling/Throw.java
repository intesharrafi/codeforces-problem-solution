package ExceptionsHandling;

 public class Throw {
    static void validDate(int age)
    {
        if(age<18){
            throw new ArithmeticException ("Not Valid");}
        else{
        System.out.println("Wellcome to Vote");}
    }
}

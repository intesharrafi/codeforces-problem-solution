
package ExceptionsHandling;

public class Example1 {
    public static void main(String[] args) {
        
    
    int x = 10;
    int y = 0;
    try
    {
        int num =x/y;
        System.out.println("next-statement: Inside try block");
    }
    catch(ArithmeticException e)
    {
        System.out.println("Exception");   
    }
    System.out.println("next-statement: Out try block");
}

}
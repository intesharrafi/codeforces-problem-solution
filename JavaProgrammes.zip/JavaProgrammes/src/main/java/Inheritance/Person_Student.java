
package Inheritance;

public class Person_Student extends Person{
    private int id = 5302;
    private double cgpa = 3.44;
    
    public void display()
    {
        System.out.println("Name = "+name);
        System.out.println("Age = "+age);
        System.out.println("I'D = "+this.id);
        System.out.println("Cgpa = "+this.cgpa);
    }
    public static void main(String[] args) {
        Person_Student obj = new Person_Student();
        obj.display();

    }
}
















package Inheritance;

public class Person {
  protected String name = "Rafi";
  protected int age = 22;
    
}

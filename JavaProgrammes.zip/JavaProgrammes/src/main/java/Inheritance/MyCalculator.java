package Inheritance;

public class MyCalculator extends Calculator {
    public void multiplication(int x, int y)
    {
        z = x*y;
        System.out.println("Multiplication = "+z);
    }
    public void division(int x, int y)
    {
        z = x/y;
        System.out.println("division = "+z);
    }
    public static void main(String[] args) {
        int a = 20,b=10;
        MyCalculator obj = new MyCalculator();
        obj.addition(a, b);
        obj.subtraction(a, b);
        obj.multiplication(a, b);
        obj.division(a, b);
    }
}

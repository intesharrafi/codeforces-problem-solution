package Inheritance;

public class Calculator {
    int z;
    public void addition(int x, int y)
    {
        z = x+y;
        System.out.println("Addition = "+z);
    }
    public void subtraction(int x, int y)
    {
        z = x-y;
        System.out.println("subtraction = "+z);
    }
}

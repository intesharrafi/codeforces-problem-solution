package Method_OverRiding;

public class Human {
   public void eat()
   {
       System.out.println("Human eats all foods");
   }
}

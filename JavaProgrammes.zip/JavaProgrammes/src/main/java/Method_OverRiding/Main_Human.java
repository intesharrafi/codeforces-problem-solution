package Method_OverRiding;

public class Main_Human {
    public static void main(String[] args) {
        Human_Boy obj = new Human_Boy();
        Human_Girl obj1 = new Human_Girl();
        Human obj3 = new Human();
        obj3.eat();
        obj.eat();
        obj1.eat();
    }
  
}

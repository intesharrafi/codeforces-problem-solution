package Method_OverRiding;

public class Human_Girl extends Human {
    public void eat()
    {
        System.out.println("Girls eat fish");
    }
}

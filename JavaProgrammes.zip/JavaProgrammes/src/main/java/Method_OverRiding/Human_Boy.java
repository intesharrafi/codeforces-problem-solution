package Method_OverRiding;

public class Human_Boy extends Human{
    public void eat()
    {
        System.out.println("Boy eats meet");
    }
}

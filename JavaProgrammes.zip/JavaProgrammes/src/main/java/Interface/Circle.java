package Interface;

public class Circle implements Drawing {
  @Override
  public void draw()
  {
      System.out.println("I am drawing a circle");
  }
}

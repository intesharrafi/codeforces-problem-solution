package Interface;

public class Line implements Drawing {
   @Override
   public void draw()
   {
       System.out.println("I am drawing a line");
   }
}

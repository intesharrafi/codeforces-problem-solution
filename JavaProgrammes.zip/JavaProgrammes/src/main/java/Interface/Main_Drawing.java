package Interface;

public class Main_Drawing {
    public static void main(String[] args) {
        Line l = new Line();
        Circle c = new Circle();
        l.draw();
        c.draw();
    }
 
}

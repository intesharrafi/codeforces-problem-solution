package Interface;
public interface Drawing {
  public void draw();  
}

package Encapsulation;

public class Student_Main {
    public static void main(String[] args) {
        Student S = new Student();
        S.setName("Rafi");
        S.setId(5302);
        S.setCgpa(3.44);
        S.display();
    }
 
}

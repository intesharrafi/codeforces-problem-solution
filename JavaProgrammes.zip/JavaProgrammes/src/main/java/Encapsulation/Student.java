package Encapsulation;

public class Student {
    private String name;
    private int id;
    private double cgpa;
    
    public void setName(String name)
    {
        this.name=name;
    }
    public void setId(int id)
    {
        this.id=id;
    }
    public void setCgpa(double cgpa)
    {
        this.cgpa=cgpa;
    }
    public String getName()
    {
        return name;
    }
    public int getId()
    {
        return id;
    }
    public double getCgpa()
    {
        return cgpa;
    }
    public void display()
    {
        System.out.println("Name : "+getName());
        System.out.println("Id : "+getId());
        System.out.println("Cgpa : "+getCgpa());
    }
}


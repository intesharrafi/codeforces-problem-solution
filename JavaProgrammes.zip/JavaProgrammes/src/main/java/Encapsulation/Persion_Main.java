package Encapsulation;

public class Persion_Main {
    public static void main(String[] args) {
      Person P = new Person();
      P.setName("Rafi");
      P.setAge(22);
      P.display();
      
    }
}


package Super_keyword;

public class Car extends Vehicle {
    private int speed=50;
    public  Car()
    {
        super.Vehicle(100);
        super.display();
        System.out.println("Car is created");
    }
    public void display()
    {
        
        System.out.println("Speed = "+this.speed);
    }
    public static void main(String[] args) {
        Car C = new Car();
        C.display();
        
    }
}

package Super_keyword;

public class Vehicle {
    protected int speed = 50;
    public void Vehicle(int x)
    {
       this.speed=x; 
    }
    public void display()
    {
        System.out.println("Speed = "+speed);
    }
}

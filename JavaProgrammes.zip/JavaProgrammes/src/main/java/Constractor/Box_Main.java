package Constractor;

public class Box_Main {
    public static void main(String[] args) {
        Box B = new Box();
        Box B1 = new Box(50,100);
        B.display();
        B1.display();
    }
  
}

package Constractor;

public class Employe_Main {
    public static void main(String[] args) {
        Employe E = new Employe();
        Employe E1 = new Employe(100);
        E.display();
        E1.display();
    }
  
}

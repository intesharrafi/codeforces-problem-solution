package Constractor;

public class Box {
    private int height,width;
    
    public Box()
    {
        height=10;
        width=15;
    }
    public Box(int height,int width)
    {
        this.height=height;
        this.width=width;
    }
    public void display()
    {
        System.out.println("Height = "+height);
        System.out.println("Width = "+width);
    }
}

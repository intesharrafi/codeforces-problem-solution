package Constractor;

public class Employe {
  private int var;
  
  public Employe()
  {
      var=10;
  }
  public Employe(int var)
  {
      this.var=var;
  }
  public int getVar()
  {
      return var;
  }
  public void display()
  {
      System.out.println("Var1 = "+var);
      System.out.println("Var2 = "+getVar());
  }
}
